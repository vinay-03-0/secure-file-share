import React from 'react';

function App() {
  return (
    <div>
      <h1>Secure File Sharing Frontend</h1>
    </div>
  );
}

export default App;