package com.secureshare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurefileshareApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecurefileshareApplication.class, args);
    }
}